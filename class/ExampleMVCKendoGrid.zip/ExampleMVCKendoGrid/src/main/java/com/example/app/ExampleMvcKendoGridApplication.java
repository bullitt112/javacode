package com.example.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExampleMvcKendoGridApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExampleMvcKendoGridApplication.class, args);
    }
}
