$(document).ready(function(){

	$('.tax_result').popover();

});